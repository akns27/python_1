def find_num(a):
  if len(a) == 0:
    return 0
  return max(a)

a = list(map(int, input().split()))
result = find_num(a)
print(result)
