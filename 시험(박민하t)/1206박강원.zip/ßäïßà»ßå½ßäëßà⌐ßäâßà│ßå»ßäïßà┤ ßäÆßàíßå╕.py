def add(a):
  if len(a) == 0:
    return 0
  num = a.pop()
  return num + add(a)

a = list(map(int, input().split()))
result = add(a)
print(result)
