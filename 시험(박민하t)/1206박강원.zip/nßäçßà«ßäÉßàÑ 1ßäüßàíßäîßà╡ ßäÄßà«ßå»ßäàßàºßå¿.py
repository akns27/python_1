def out(a):
  print(a, end = ' ')
  a -= 1
  if a <= 0:
    return False
  out(a)

insert = int(input())
out(insert)